module.exports = {
    src: require('./src/index.js'),
}