module.exports = {
    KakaoDB: require('./KakaoDB').KakaoDB
}